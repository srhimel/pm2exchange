"use strict";
(() => {
var exports = {};
exports.id = 730;
exports.ids = [730];
exports.modules = {

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 685:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const conversionSchema = new mongoose__WEBPACK_IMPORTED_MODULE_0__.Schema({
    currencyFrom: {
        type: Object
    },
    currencyTo: {
        type: Object
    },
    givenAmount: {
        type: Number
    },
    receiveAmount: {
        type: Number
    },
    conversionRate: {
        type: Number
    },
    walletAddress: {
        type: String
    },
    emailAddress: {
        type: String
    },
    status: {
        type: String,
        default: "PENDING"
    },
    paymentStatus: {
        type: String,
        default: "PENDING"
    }
}, {
    timestamps: true
});
const Conversion = mongoose__WEBPACK_IMPORTED_MODULE_0__.models.Conversion || (0,mongoose__WEBPACK_IMPORTED_MODULE_0__.model)("Conversion", conversionSchema);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Conversion);


/***/ }),

/***/ 3031:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Q": () => (/* binding */ connectMongo)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const connectMongo = async ()=>await mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(process.env.MONGO_URI);


/***/ }),

/***/ 7294:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Currency)
/* harmony export */ });
/* harmony import */ var server_models_conversionMode__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(685);
/* harmony import */ var server_utils_connectMongo__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3031);


async function Currency(req, res) {
    try {
        await (0,server_utils_connectMongo__WEBPACK_IMPORTED_MODULE_1__/* .connectMongo */ .Q)();
        const { search  } = req.query;
        const data = await server_models_conversionMode__WEBPACK_IMPORTED_MODULE_0__/* ["default"].find */ .Z.find({
            $or: [
                {
                    emailAddress: search
                },
                {
                    walletAddress: search
                }
            ]
        });
        res.status(200).json(data);
    } catch (error) {
        console.log(error);
        res.json({
            error: error.message
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7294));
module.exports = __webpack_exports__;

})();