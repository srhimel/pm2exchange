"use strict";
(() => {
var exports = {};
exports.id = 478;
exports.ids = [478];
exports.modules = {

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 685:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const conversionSchema = new mongoose__WEBPACK_IMPORTED_MODULE_0__.Schema({
    currencyFrom: {
        type: Object
    },
    currencyTo: {
        type: Object
    },
    givenAmount: {
        type: Number
    },
    receiveAmount: {
        type: Number
    },
    conversionRate: {
        type: Number
    },
    walletAddress: {
        type: String
    },
    emailAddress: {
        type: String
    },
    status: {
        type: String,
        default: "PENDING"
    },
    paymentStatus: {
        type: String,
        default: "PENDING"
    }
}, {
    timestamps: true
});
const Conversion = mongoose__WEBPACK_IMPORTED_MODULE_0__.models.Conversion || (0,mongoose__WEBPACK_IMPORTED_MODULE_0__.model)("Conversion", conversionSchema);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Conversion);


/***/ }),

/***/ 9581:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const currencySchema = new mongoose__WEBPACK_IMPORTED_MODULE_0__.Schema({
    label: {
        type: String
    },
    key: {
        type: String
    },
    icon: {
        type: String
    },
    walletAddress: {
        type: String
    }
}, {
    timestamps: true
});
const Currency = mongoose__WEBPACK_IMPORTED_MODULE_0__.models.Currency || (0,mongoose__WEBPACK_IMPORTED_MODULE_0__.model)("Currency", currencySchema);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Currency);


/***/ }),

/***/ 3031:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Q": () => (/* binding */ connectMongo)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const connectMongo = async ()=>await mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(process.env.MONGO_URI);


/***/ }),

/***/ 5704:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Currency)
});

// EXTERNAL MODULE: ./server/models/conversionMode.js
var conversionMode = __webpack_require__(685);
// EXTERNAL MODULE: ./server/models/currencyModel.js
var currencyModel = __webpack_require__(9581);
;// CONCATENATED MODULE: ./server/controller/conversionController.js


const createConversion = async (req, res)=>{
    try {
        const newConversion = new conversionMode/* default */.Z(req.body);
        const data = await newConversion.save();
        res.status(200).json(data);
    } catch (error) {
        res.status(500).json({
            message: "There is a n error",
            error: error.message
        });
    }
};
const getConversion = async (req, res)=>{
    try {
        const { id  } = req.query || {};
        let data;
        if (id) {
            data = await conversionMode/* default.findById */.Z.findById(id);
        } else {
            data = await conversionMode/* default.find */.Z.find().sort({
                createdAt: -1
            });
        }
        res.status(200).json(data);
    } catch (error) {
        res.status(500).json({
            message: "There is a n error",
            error: error.message
        });
    }
};
const deleteConversion = async (req, res)=>{
    try {
        const { id  } = req.query;
        await conversionMode/* default.findByIdAndRemove */.Z.findByIdAndRemove(id);
        res.status(200).json({
            message: `Deleted Conversion ${id}`
        });
    } catch (error) {
        res.status(500).json({
            message: "There is a n error",
            error: error.message
        });
    }
};
const editConversion = async (req, res)=>{
    try {
        const { id  } = req.query;
        const ConversionInput = req.body;
        const data = await conversionMode/* default.findByIdAndUpdate */.Z.findByIdAndUpdate(id, ConversionInput);
        res.status(200).json({
            message: "Edited Conversion",
            data
        });
    } catch (error) {
        res.status(500).json({
            message: "There is a n error",
            error: error.message
        });
    }
};

// EXTERNAL MODULE: ./server/utils/connectMongo.js
var connectMongo = __webpack_require__(3031);
;// CONCATENATED MODULE: ./src/pages/api/conversion.js


async function Currency(req, res) {
    try {
        await (0,connectMongo/* connectMongo */.Q)();
        switch(req.method){
            case "GET":
                await getConversion(req, res);
                break;
            case "POST":
                await createConversion(req, res);
                break;
            case "PUT":
                await editConversion(req, res);
                break;
            case "DELETE":
                await deleteConversion(req, res);
                break;
            default:
                res.status(200).json({
                    message: "API is working"
                });
                break;
        }
    } catch (error) {
        console.log(error);
        res.json({
            error
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(5704));
module.exports = __webpack_exports__;

})();