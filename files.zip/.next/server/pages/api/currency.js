"use strict";
(() => {
var exports = {};
exports.id = 985;
exports.ids = [985];
exports.modules = {

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 9581:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const currencySchema = new mongoose__WEBPACK_IMPORTED_MODULE_0__.Schema({
    label: {
        type: String
    },
    key: {
        type: String
    },
    icon: {
        type: String
    },
    walletAddress: {
        type: String
    }
}, {
    timestamps: true
});
const Currency = mongoose__WEBPACK_IMPORTED_MODULE_0__.models.Currency || (0,mongoose__WEBPACK_IMPORTED_MODULE_0__.model)("Currency", currencySchema);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Currency);


/***/ }),

/***/ 3031:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Q": () => (/* binding */ connectMongo)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const connectMongo = async ()=>await mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(process.env.MONGO_URI);


/***/ }),

/***/ 9089:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Currency)
});

// EXTERNAL MODULE: ./server/models/currencyModel.js
var currencyModel = __webpack_require__(9581);
;// CONCATENATED MODULE: ./server/controller/currencyController.js

const createCurrency = async (req, res)=>{
    try {
        const newCurrency = new currencyModel/* default */.Z(req.body);
        const data = await newCurrency.save();
        res.status(200).json({
            message: "New Currency added",
            data
        });
    } catch (error) {
        res.status(500).json({
            message: "There is an error",
            error: error.message
        });
    }
};
const getCurrencies = async (req, res)=>{
    try {
        const { id  } = req.query || {};
        let data;
        if (id) {
            data = await currencyModel/* default.findById */.Z.findById(id);
        } else {
            data = await currencyModel/* default.find */.Z.find();
        }
        res.status(200).json(data);
    } catch (error) {
        res.status(500).json({
            message: "There is a n error",
            error: error.message
        });
    }
};
const deleteCurrency = async (req, res)=>{
    try {
        const { id  } = req.query;
        await currencyModel/* default.findByIdAndRemove */.Z.findByIdAndRemove(id);
        res.status(200).json({
            message: `Deleted Currency ${id}`
        });
    } catch (error) {
        res.status(500).json({
            message: "There is a n error",
            error: error.message
        });
    }
};
const editCurrency = async (req, res)=>{
    try {
        const { id  } = req.query;
        const currencyInput = req.body;
        const data = await currencyModel/* default.findByIdAndUpdate */.Z.findByIdAndUpdate(id, currencyInput);
        res.status(200).json({
            message: "Edited Currency",
            data
        });
    } catch (error) {
        res.status(500).json({
            message: "There is a n error",
            error: error.message
        });
    }
};

// EXTERNAL MODULE: ./server/utils/connectMongo.js
var connectMongo = __webpack_require__(3031);
;// CONCATENATED MODULE: ./src/pages/api/currency.js


async function Currency(req, res) {
    try {
        await (0,connectMongo/* connectMongo */.Q)();
        switch(req.method){
            case "GET":
                await getCurrencies(req, res);
                break;
            case "POST":
                await createCurrency(req, res);
                break;
            case "PUT":
                await editCurrency(req, res);
                break;
            case "DELETE":
                await deleteCurrency(req, res);
                break;
            default:
                res.status(200).json({
                    message: "API is working"
                });
                break;
        }
    } catch (error) {
        console.log(error);
        res.json({
            error
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(9089));
module.exports = __webpack_exports__;

})();