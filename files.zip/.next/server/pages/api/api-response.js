"use strict";
(() => {
var exports = {};
exports.id = 917;
exports.ids = [917];
exports.modules = {

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 5882:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ getApiResponse),
/* harmony export */   "q": () => (/* binding */ createApiResponse)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var server_models_apiResponseModel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8229);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const createApiResponse = async (req, res)=>{
    try {
        const response = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get(`http://api.coinlayer.com/live?access_key=${process.env.COINLAYER}`);
        const apiData = await response.data;
        await server_models_apiResponseModel__WEBPACK_IMPORTED_MODULE_1__/* ["default"].deleteMany */ .Z.deleteMany();
        const newApiResponse = new server_models_apiResponseModel__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z({
            response: apiData
        });
        const data = await newApiResponse.save();
        res.status(200).json({
            message: "New Api Response added",
            data
        });
    } catch (error) {
        res.status(500).json({
            message: "There is a n error",
            error: error.message
        });
    }
};
const getApiResponse = async (req, res)=>{
    try {
        const data = await server_models_apiResponseModel__WEBPACK_IMPORTED_MODULE_1__/* ["default"].find */ .Z.find();
        if (!data.length) {
            res.status(200).json({
                message: "No Data Found",
                data: []
            });
        } else {
            const apiResponse = data[0].response;
            apiResponse["rates"]["PL"] = 1;
            apiResponse["rates"]["PM"] = 1;
            res.status(200).json(apiResponse);
        }
    } catch (error) {
        res.status(500).json({
            message: "There is a n error",
            error: error.message
        });
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8229:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const apiResponseSchema = new mongoose__WEBPACK_IMPORTED_MODULE_0__.Schema({
    response: {
        type: Object
    }
}, {
    timestamps: true
});
const ApiResponse = mongoose__WEBPACK_IMPORTED_MODULE_0__.models.ApiResponse || (0,mongoose__WEBPACK_IMPORTED_MODULE_0__.model)("ApiResponse", apiResponseSchema);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ApiResponse);


/***/ }),

/***/ 3031:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Q": () => (/* binding */ connectMongo)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const connectMongo = async ()=>await mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(process.env.MONGO_URI);


/***/ }),

/***/ 3856:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ApiResponse)
/* harmony export */ });
/* harmony import */ var server_controller_apiResponseController__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5882);
/* harmony import */ var server_utils_connectMongo__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3031);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([server_controller_apiResponseController__WEBPACK_IMPORTED_MODULE_0__]);
server_controller_apiResponseController__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


async function ApiResponse(req, res) {
    try {
        await (0,server_utils_connectMongo__WEBPACK_IMPORTED_MODULE_1__/* .connectMongo */ .Q)();
        switch(req.method){
            case "GET":
                await (0,server_controller_apiResponseController__WEBPACK_IMPORTED_MODULE_0__/* .getApiResponse */ .A)(req, res);
                break;
            case "POST":
                await (0,server_controller_apiResponseController__WEBPACK_IMPORTED_MODULE_0__/* .createApiResponse */ .q)(req, res);
                break;
            default:
                res.status(200).json({
                    message: "API is working"
                });
                break;
        }
    } catch (error) {
        console.log(error);
        res.json({
            error
        });
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3856));
module.exports = __webpack_exports__;

})();