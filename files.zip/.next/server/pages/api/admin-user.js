"use strict";
(() => {
var exports = {};
exports.id = 20;
exports.ids = [20];
exports.modules = {

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 3031:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Q": () => (/* binding */ connectMongo)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const connectMongo = async ()=>await mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(process.env.MONGO_URI);


/***/ }),

/***/ 6905:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ApiResponse)
});

// EXTERNAL MODULE: external "mongoose"
var external_mongoose_ = __webpack_require__(1185);
;// CONCATENATED MODULE: ./server/models/userModel.js

const userSchema = new external_mongoose_.Schema({
    name: {
        type: String
    },
    username: {
        type: String
    },
    email: {
        type: String
    },
    password: {
        type: String
    },
    role: {
        type: String
    }
}, {
    timestamps: true
});
const User = external_mongoose_.models.User || (0,external_mongoose_.model)("User", userSchema);
/* harmony default export */ const userModel = (User);

;// CONCATENATED MODULE: ./server/controller/userController.js

const createUser = async (req, res)=>{
    try {
        const newUser = new userModel(req.body);
        const data = await newUser.save();
        res.status(200).json(data);
    } catch (error) {
        res.status(500).json({
            message: "There is a n error",
            error: error.message
        });
    }
};
const validateUser = async (req, res)=>{
    try {
        console.log("I am getting a call");
        const { email , password  } = req.body;
        const user = await userModel.findOne({
            email,
            password
        });
        if (user) {
            const sendUser = {
                name: user.name,
                userName: user.username,
                email: user.email,
                role: user.role
            };
            res.status(200).json(sendUser);
        } else {
            res.status(500).json({
                message: "No user found"
            });
        }
    } catch (error) {
        res.status(500).json({
            message: "There is a n error",
            error: error.message
        });
    }
};

// EXTERNAL MODULE: ./server/utils/connectMongo.js
var connectMongo = __webpack_require__(3031);
;// CONCATENATED MODULE: ./src/pages/api/admin-user.js


async function ApiResponse(req, res) {
    try {
        await (0,connectMongo/* connectMongo */.Q)();
        switch(req.method){
            case "POST":
                await createUser(req, res);
                break;
            case "PUT":
                await validateUser(req, res);
                break;
            default:
                res.status(200).json({
                    message: "API is working"
                });
                break;
        }
    } catch (error) {
        console.log(error);
        res.json({
            error
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6905));
module.exports = __webpack_exports__;

})();