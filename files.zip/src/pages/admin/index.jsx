import React from 'react'

const index = () => {
  return <div>Admin Page</div>
}

export default index
